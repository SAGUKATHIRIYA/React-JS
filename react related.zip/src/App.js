import React from 'react';
import './App.css';

import PropsType from "./component/PropsType";

function App(props) {
    return (
    <div>
        <h1> i am React app </h1>
        {/*<Main/>*/}
        <PropsType/>
        <h1> hello {props.name} </h1>
    </div>
  )
}
export default App;
