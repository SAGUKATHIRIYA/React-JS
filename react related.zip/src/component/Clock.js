// import React, {Component} from 'react';
// function Clock(){
//     return(
// //            <body onload="display_ct()">
//         function display_c()
//         {
//             var refresh = 1000;
//             mytime = setTimeout('display_ct()', refresh);
//         }
//         function display_ct()
//         {
//             var d = new Date();
//             document.getElementById('demo').innerHTML = d;
//             display_c();
//         }
//
//         function display_c()
//         {
//             var refresh = 1000;
//             mytime = setTimeout('display_ct()', refresh);
//         }
//         function display_ct()
//         {
//             var d = new Date();
//             document.getElementById('demo').innerHTML = d;
//             display_c();
//         }
//         )
// }
// export default Clock;
//
//
// //<body onload="display_ct()">
//
//
//
