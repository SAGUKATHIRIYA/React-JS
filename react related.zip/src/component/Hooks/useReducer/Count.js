import React, {useReducer} from "react";

    const initialState = 0;
    const reducer = (state, action) => {
        console.log(state, action);
        if (action.type === "INCREMENT") {
            return state + 1;
        }
        if (action.type === "DECREMENT") {
            return state - 1;
        }
        if (action.type === "RESET") {
            return initialState;
        }
        return state;
    };

    const Count = () => {
        const [count, dispatch] = useReducer(reducer, initialState);

        return (
            <>
                <div>
                    <h1> i am increment & decrement and also reset </h1>
                    <h1>{count}</h1>
                    <button onClick={() => dispatch({type: "INCREMENT"})}>Increment</button>
                    <button onClick={() => dispatch({type: "DECREMENT"})}>Decrement</button>
                    <button onClick={() => dispatch({type: "RESET"})}>Reset</button>
                </div>
            </>
        )
    };

export default Count;