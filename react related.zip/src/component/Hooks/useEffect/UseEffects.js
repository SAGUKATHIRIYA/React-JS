import React, {useEffect, useState} from "react";
function UseEffects() {
    const[count,setCount]=useState(0);
    useEffect(()=>{
        console.log("hello useEffect");
    });
    console.log("i am ouside");
    console.log("i am outer");
    function Counter() {
        setCount(count+1);
    }
    return(
        <div>
            <h1> this is the useEffects </h1>
            <h2>{count}</h2>
            <button onClick={Counter}>click me</button>
        </div>
    )
}
export default UseEffects;