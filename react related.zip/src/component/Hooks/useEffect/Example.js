import React, {useEffect, useState} from "react";
function Example() {
    const[count,setCount]=useState(0);
    function Example1() {
        setCount(count+1);
    }
    useEffect(()=>{
        //run karvi tyare numbers dekhade
        document.title = `you clicked (${count}) times`;
        console.log("hello useEffect");
    },[count]);
    console.log("hello outside");
    return(
        <div>
            <h1> hello i am Example of UseEffect </h1>
            <p><b>i am {count} button </b></p>
            <button onClick={Example1}>Click me </button>
        </div>
    )
}
export default Example;