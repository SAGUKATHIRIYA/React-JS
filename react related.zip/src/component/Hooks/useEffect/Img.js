import React, {useEffect} from "react";
import img from "./images/doctor-strange6.jpg" ;

function Img() {
    useEffect(()=>{
        console.log("img component Mounted ");
        //destroied thase atle return ma jase
        return()=>{
            console.log("component has Unmounted")
        };
    },[]);
    return(
        <div className="container">
        <h1> I am img component </h1>
            <img src={img}></img>
        </div>
    )
}
export default Img;