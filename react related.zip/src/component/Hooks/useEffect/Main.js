import React, {useEffect, useState} from "react";
import Img from "./Img";
function Main() {
    const [name,setName]=useState("sagu");
    const [number,setNumber]=useState(0);
    const [isShowing, setIsShowing]=useState(false);
    // console.log("i am main component ")
    useEffect(()=>{
        console.log("Component has Mounted");
    },[]);
    //[name,number]; je apvi ae click karvi tyare run thay empty hoy to only one time thay
    function inc() {
       setNumber(number+1);
    }
    function dec(){
        setNumber(number-1);
    }

    return(
        <div className="container">
        <h1> ich bin Main in UseEffect</h1>
            <h2> my name is: {name}</h2>
            <button onClick={()=> setName("KRISHNA")}> change name </button>
            <hr/>
            <h2> Total items {number} </h2>
            <button onClick={inc}> Inc </button>
            <button onClick={dec}> Dec</button>
            <hr/>
            <button onClick={()=>setIsShowing(!isShowing)}> show / hide </button>
            {
                isShowing ? <Img/> : ""
            }
        </div>
    )
}
export default Main;