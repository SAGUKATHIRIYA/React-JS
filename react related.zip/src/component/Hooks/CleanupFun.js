import React, {useEffect, useState} from "react";
function CleanupFun() {
    const[widthCount,setWidthCount]=useState(window.screen.width);
        function ActualWidth(){
            console.log(window.innerWidth);
            setWidthCount(window.innerWidth);
        }
    useEffect(()=>{
        console.log("add event");
        window.addEventListener("resize",ActualWidth);
        return()=>{
            console.log("remove event");
            window.removeEventListener("resize",ActualWidth);
        }
    });
    return(
        <div>
            <h1> i am clean up function</h1>
            <p> The actual size of the window: </p>
            <h2> {widthCount}</h2>
        </div>
    )
}
export default CleanupFun;