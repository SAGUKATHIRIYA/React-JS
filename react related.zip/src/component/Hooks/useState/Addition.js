import React, {useState} from "react";
function Addition() {
const [counter,setCounter]= useState(0)

function Increment() {
        setCounter(counter+1);
        console.log(counter)
}
        return(
        <div>
        <h1> i am addition function</h1>
            {counter} <br/>
            <button onClick={Increment}>click me</button>
        </div>
    )
}
export default Addition;
