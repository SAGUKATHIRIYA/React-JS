import React, {useState} from "react";

function Main() {
    const [userName,setUserName]=useState("sagu kathiriya");
    const [age,setAge]=useState("63");
    const [address,setAddress]=useState("katargam");
    const [number,setNumber]=useState(5);

    function changeName() {
        setUserName("MONIKA PATEL");
        setAge(52);
        setAddress("Umra");
    }
    
    function inc() {
            setNumber(number+1);
    }
    
    function dec() {
        if (number > 0) {
            setNumber(number - 1);
        }
    }

    return(
        <>
        <div className='container'>
            <h1> i am main</h1>
            <div className="card">
                <h2> my Name is : {userName}</h2>
                <h2> my Age is :{age}</h2>
                <h2> my Address is : {address}</h2>
                {/* usestate through value change thay*/}
                {/*<button onClick={()=>setUserName("Monika patel")}> Change the user</button>*/}
                <button onClick={changeName}> useState Change</button>
            </div>
        </div>
            <div className="container m-8 p-5">
                <div className="card p-3">
                    <h2> Counter Clicked</h2>
                    <h3> Initial Number: {number} </h3>
                    <div>
                    <button onClick={inc} className="btn btn-secondary">+</button>
                    <button onClick={dec} className="btn btn-dark">-</button>
                    </div>
                </div>
            </div>
        </>
    )
}
export default Main;