import React, {useState} from "react";

function ButtonChange() {
    const[details,setDetails]=useState({
        UserName: "nathani",
        Email: "nathani@gmail.com",
        contact: 5632561230
    })

    function changeDetails(){
            setDetails(
                {
                    //previous value and then je change karvu ae muki devanu
                    ...details,  Email: "sagukathiriya@gmail.com", contact: 8844555666999
                }
            )
    }
    return(
        <>
            <div className="container p-5">
                <h2> Hello i am ButtonChange </h2>
                <div className="card">
                    <div className="card-body">
                        <h2> UserName: {details.UserName} </h2>
                        <h2> Email: {details.Email}</h2>
                        <h2> contact: {details.contact}</h2>
                        <button onClick={changeDetails}> Change Me </button>
                    </div>
                </div>
            </div>
        </>
    )
}
export default ButtonChange;