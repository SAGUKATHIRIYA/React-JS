import React, {useState} from "react";
function TextUseState() {
    const[inputtext,setInputtext]=useState("");

    function InputBox(e){
        const newValue=e.target.value;
        // setInputtext(newValue);
        console.log(newValue);
    }
    return(
        <div>
            <h1> i am textBox with useState </h1>
            {inputtext}
            <input placeholder="enter the box something...." onChange={InputBox}/>
        </div>
    )
}
export default TextUseState;