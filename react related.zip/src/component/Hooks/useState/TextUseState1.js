import React, {useState} from "react";
function TextUseState1() {
    const[textvalue,setTextvalue]=useState(0);
    const[showtext,setShowtext]=useState(true);
    function TextBox() {
        setTextvalue(textvalue+1);
        setShowtext(!showtext);
    }
    return(
        <div className="container">
            <h1> i am TextUseState1 </h1>
            <h1>{textvalue}</h1>
            <button onClick={TextBox}> Click me </button> <br/>
            <h4>{showtext && <p> this is a valid text </p>} </h4>
        </div>
    )
}
export default TextUseState1;