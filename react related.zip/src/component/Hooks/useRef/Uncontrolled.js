import React from "react";
function Uncontrolled() {
    return(
        <div>
            <h1> i am controlled </h1>
            <form>
            <input type="text"/>
            <button> Here I am </button>
            </form>
        </div>
    )
}
export default Uncontrolled;