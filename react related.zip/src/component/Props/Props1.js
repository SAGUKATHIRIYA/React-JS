import React,{Component} from 'react';
class Props1 extends Component{
    render(){
        return(
            <h1> ich bin class with props {this.props.name} </h1>
        )
    }
}
export default Props1;