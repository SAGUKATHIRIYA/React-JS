import React, {Component} from 'react';
class Parents extends Component{
       render(){
               return(
                    <div>
                        <Child name = {"sagu kathiriya"}/>
                        <Child address = {"katargam"}/>
                        <Child handy  = {7575884665}/>
                    </div>
               )
       }
}
class Child extends Component{
        render(){
            return(
                <div>
                    {this.props.name}
                    {this.props.address}
                    {this.props.handy}
                </div>
            );
        }
}
export default Parents;