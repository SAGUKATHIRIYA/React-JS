import React from "react";
function MovieList(props) {
    const {data} = props;
    console.log(data);
    return(
        <div>
        <h1> {data.MovieName}</h1>
        <p> {data.title} </p>
            {""}
        </div>
    );
}
export default MovieList;