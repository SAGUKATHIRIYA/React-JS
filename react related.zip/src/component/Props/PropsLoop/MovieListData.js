
const MovieListData=[
    {
        id:1,
        MovieName:"Gangubai Kathiawadi",
        title:"Gangubai Kathiawadi is a 2022 Indian Hindi-language biographical c",
    },
    {
        id:2,
        MovieName:"KFC",
        title:"Gangubai Kathiawadi is a 2022 Indian Hindi-language biographical c",
    },
    {
        id:3,
        MovieName:"HINDU",
        title:"Gangubai Kathiawadi is a 2022 Indian Hindi-language biographical c",
    },
    {
        id:4,
        MovieName:"Kathiawadi",
        title:"Gangubai Kathiawadi is a 2022 Indian Hindi-language biographical c",
    },
];
export default MovieListData;