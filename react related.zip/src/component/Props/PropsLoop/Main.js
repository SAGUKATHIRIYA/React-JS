import MovieListData from "./MovieListData";
import MovieList from "./MovieList";
import React from "react";

function Main() {
        return(
            <div className="container py-5">
                <h1 style={{color:"red" , textAlign: "center" , textDecorationLine: "underline"}}> i am main movie component </h1>
                {/*item all, index ,  entire value*/}
                {MovieListData.map((item,index,ent)=>{
                    console.log(item);
                    return <MovieList data={item}/>;
                })}
            </div>
        )
}
export default Main;