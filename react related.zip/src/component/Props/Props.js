import React from 'react';
function Props(props){
    return <h1> ich bin function with props   {props.name} </h1>
    }
export default Props;