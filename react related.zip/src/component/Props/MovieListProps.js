import React from 'react';


function MovieListProps(props) {
//       console.log(props);
    return(
        <div className="card p-3 mb-4">
               <h1>{props.title}</h1>
               <hr/>
               <p>{props.desc}</p>
               <button className="btn btn-dark"> Watch Now </button>
        </div>
    )
}
export default MovieListProps;