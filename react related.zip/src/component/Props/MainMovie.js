import React from 'react';
import MovieListProps from './MovieListProps';

function MainMovie(){
    return(
       <div className="container">
                   <h1> Movie lists </h1>
                       < MovieListProps
                                title='Gangubai Kathiawadi'
                                desc='Gangubai Kathiawadi is a 2022 Indian Hindi-language biographical crime drama film directed by Sanjay Leela Bhansali and produced by Jayantilal Gada and ...'
                       />
                       < MovieListProps
                                title=' The Batman'
                                desc='When the Riddler, a sadistic serial killer, begins murdering key political figures in Gotham, Batman is forced to investigate the city&apos;s hidden corruption and question his family&apos;s involvement.'
                       />
                       < MovieListProps
                                title='  The Kashmir Files'
                                desc='The Kashmir Files&apos;is a story, based on video interviews of the first generation victims of the Genocide of Kashmiri Pandit Community In 1990.'
                        />
                        < MovieListProps
                                title='  Deep Water'
                                desc='The Kashmir Files&apos;is a story, based on video interviews of the first generation victims of the Genocide of Kashmiri Pandit Community In 1990.'
                        />
       </div>
    )
}
export default MainMovie;






