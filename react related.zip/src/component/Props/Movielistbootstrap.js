import React from 'react';

function Movielistbootstrap(){
    return(
        <div className="container">
            <h1> Top 4 Movies List </h1>
            <div className= "card">
                <h2 className="card-py-1"> <b> Gehraiya </b> </h2>
                <hr/>
                <p> The oldest classical Greek and Latin writing had little or no space between words and could be written in boustrophedon (alternating directions). Over time, text direction (left to right) became standardized, and word dividers and terminal punctuation became common. The first way to divide sentences into groups was the original paragraphs, similar to an underscore at the beginning of the new group.[2] The Greek parágraphos evolved into the pilcrow (¶), which in English manuscripts in the Middle Ages can be seen inserted inline between sentences. The hedera leaf (e.g. ☙) has also been used in the same way.</p>
               <button className="btn-btn-primary"> Watch Now </button>
             </div>
              <div className= "card">
                  <h2 className="card-py-1"> <b> Gangu Bai </b> </h2>
                  <hr/>
                  <p> The oldest classical Greek and Latin writing had little or no space between words and could be written in boustrophedon (alternating directions). Over time, text direction (left to right) became standardized, and word dividers and terminal punctuation became common. The first way to divide sentences into groups was the original paragraphs, similar to an underscore at the beginning of the new group.[2] The Greek parágraphos evolved into the pilcrow (¶), which in English manuscripts in the Middle Ages can be seen inserted inline between sentences. The hedera leaf (e.g. ☙) has also been used in the same way.</p>
                  <button className="btn-btn-primary"> Watch Now </button>
               </div>
               <div className= "card">
                   <h2 className="py-1"> <b> The Kashmir Flies  </b> </h2>
                   <hr/>
                   <p> The oldest classical Greek and Latin writing had little or no space between words and could be written in boustrophedon (alternating directions). Over time, text direction (left to right) became standardized, and word dividers and terminal punctuation became common. The first way to divide sentences into groups was the original paragraphs, similar to an underscore at the beginning of the new group.[2] The Greek parágraphos evolved into the pilcrow (¶), which in English manuscripts in the Middle Ages can be seen inserted inline between sentences. The hedera leaf (e.g. ☙) has also been used in the same way.</p>
                   <button className="btn-btn-primary"> Watch Now </button>
                   </div>
                <div className= "card">
                     <h2 className="py-1"> <b> Radhe Shyam </b> </h2>
                     <hr/>
                     <p> The oldest classical Greek and Latin writing had little or no space between words and could be written in boustrophedon (alternating directions). Over time, text direction (left to right) became standardized, and word dividers and terminal punctuation became common. The first way to divide sentences into groups was the original paragraphs, similar to an underscore at the beginning of the new group.[2] The Greek parágraphos evolved into the pilcrow (¶), which in English manuscripts in the Middle Ages can be seen inserted inline between sentences. The hedera leaf (e.g. ☙) has also been used in the same way.</p>
                     <button className="card-title"> Watch Now </button>
                     </div>

        </div>
    )
}
export default Movielistbootstrap;