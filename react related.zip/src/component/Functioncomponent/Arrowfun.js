import React from 'react';

const Arrowfun = () => {
    return <h1> i am arrow fun </h1>
}
export default Arrowfun;