import React from 'react';

const Funexpersion = function(){
    return <h1> i am fun expression </h1>
}
export default Funexpersion;