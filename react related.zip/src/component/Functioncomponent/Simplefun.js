import React from 'react';

function Simplefun(){
    return (
        <div>
            <h1> i am funcom </h1>
        </div>
    )
}
export default Simplefun;