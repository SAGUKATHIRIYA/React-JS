import React from "react";
function New(props) {
    const Name= "sagu";
    return(
        <div>
            <h1> I am new</h1>
            <h2> Hello World </h2>
            <h3> {Name} </h3>
            <h4> today is: {new Date().toLocaleString()}</h4>
            <p>Learn Python: Programize is a free Android app that makes it easy to learn Python and try out what you have learned in real-time. You can use the app to follow through Python tutorials step-by-step, experiment with Python code in each lesson using the in-built Python interpreter, take quizzes and more to learn basic concepts of Python 3 from beginning to advanced</p>
            <h1 style={{backgroundColor:"blue" , color:"red" , fontFamily:"Arial"}}>{props.name}</h1>
            <input type="text"/> 
            <button> Click me </button>


        </div>
    )
}
{/*<New name="sagu kathiriya"/> <hr/>*/}
{/*<New name="sagu"/> <hr/>*/}
{/*<New name="kathiriya"/> <hr/>*/}
export default New;