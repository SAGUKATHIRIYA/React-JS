import React,{Component} from 'react';
class ClassComponent extends Component{
    render(){
        return(
            <div>
                <h1> i am Class Component </h1>
                <h2> it is {this.props.name} </h2>
                <h3> my surname is: {this.props.surname}</h3>
            </div>
        )
    }
}
export default ClassComponent;