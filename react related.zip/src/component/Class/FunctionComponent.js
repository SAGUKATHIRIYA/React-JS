import React from 'react';
const FunctionComponent=()=>{
        return(
            <div>
                <h1> i am Function Component </h1>
            </div>
            )
        }
export default FunctionComponent;