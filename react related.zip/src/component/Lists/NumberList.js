import React from "react";
function NumberList() {
    const persons=[
        {
            id:1,
            name:"sagu",
            surname:"kathiriya",
            age:23,
            skill:"React"
        },
        {
            id:2,
            name:"unnati",
            surname:"kathiriya",
            age:24,
            skill:"designing"
        },
        {
            id:3,
            name:"vishal",
            surname:"kathiriya",
            age:25,
            skill:"Developer"
        }
    ];
    const PersonList1 = persons.map(person=>(person.name));
    const PersonList = persons.map(person=>(
        <h2>
            I am {person.name} {person.surname} and my age is : {person.age} also i love my skill is {person.skill}
        </h2>));
    return(
        <div>
            <h1> hello </h1>
            <h4> my name is: {PersonList1}</h4>
            <h2> {PersonList}</h2>
        </div>
    )
}
export default NumberList;