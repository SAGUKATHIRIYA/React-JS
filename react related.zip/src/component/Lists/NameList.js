import React from "react";
function NameList() {
    const names=["mahi","monika","payal"];
    return(
        <div>
            <h1>i am array of list</h1>
            <h2>{names[0]}</h2><hr/>
            <h2>{names[1]}</h2>

            // 2nd method
            {
                names.map(name=><h2>{name}</h2>)
            }
        </div>

    )
}
export default NameList;

