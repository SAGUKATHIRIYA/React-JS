import React from "react";
function Lists() {
    const numbers=[2,4,6,8,10,12,14,16,18,20];
    const listItems=numbers.map((numbers)=>numbers*2);
    console.log(listItems);
    return(
        <div>
            <h1> i am List and keys </h1>
            <h1><ul>
                <li key="3">mahi</li>
                <li key="2">sagu</li>
                <li key="1">kathiriya</li>
                <li key="0">kathiriya 1</li>
            </ul></h1>
            <h2> numbers is : <li>{listItems}</li> </h2>
        </div>
    )
}
export default Lists;