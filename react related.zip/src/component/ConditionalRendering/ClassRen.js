import React, {Component} from "react";
class ClassRen extends Component {
    constructor(props) {
        super(props)
        this.state = {
            isLoggedIn: true
    }
    }

    render() {
        // //condition
        // return(
        //     this.state.isLoggedIn &&
        //         <div>
        //             welcome the page
        //         </div>
        // )

        // //condition
        // return(
        // this.state.isLoggedIn ?(
        //     <div> Welcome </div>
        // ) :(
        //     <div> Welcome else part</div>
        // )
        // )

        // //condition
        // let message
        // if(this.state.isLoggedIn){
        //     message = <div> <h1> Welcome of the page</h1></div>
        // }else{
        //     message = <div> Welcome of the page for else </div>
        // }
        // return(
        //     <div>{message}</div>
        // )

        // //condition
        // if (this.state.isLoggedIn) {
        //     return (
        //         <div>
        //             <h1> i am render </h1>
        //         </div>
        //     )
        // } else {
        //     return (
        //         <div>
        //             <h1> hello i am class rendering</h1>
        //         </div>
        //     )
        // }
        return(
            <div>
                <h1> i am rendering </h1>
            </div>
        )
    }
}
export default ClassRen;