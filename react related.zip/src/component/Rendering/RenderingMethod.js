function App() {
  return (
      <div>
        <h1> app.js ma direct thay </h1>
        <p> " su dekhadvu che , ""kya dekhdvu che" </p>
    </div>,
    document.getElementById("root")
    </div>
  );
}

export default App;