import React, {Component} from "react";
class ClickClass extends Component{
    Handle(){
        console.log("clicked");
        document.write("hello clicked");
    }
    render() {
        return(
            <div>
            <h1> i am ClickClass rendering </h1>
                <button onClick={this.Handle}> Click me </button>
            </div>
        )
    }
}
export default ClickClass;