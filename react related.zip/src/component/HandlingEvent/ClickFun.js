import React from "react";
function ClickFun() {
    function Handle(){
        console.log("i am clicked");
        document.write("hello clicked");
    }
    return(
        <div>
            <h1> i am click in handling</h1>
            <button onClick={Handle}>Click me</button>
        </div>
    )
}
export default ClickFun;