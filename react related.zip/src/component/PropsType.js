import React from "react";
import App from "../App";

function PropsType() {
    return(
        <div>
            <App name = "123"/>
            <App name = "123"/>
            <App name = "123"/>
        </div>
    )
}
export default PropsType;