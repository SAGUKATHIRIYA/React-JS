import React, {useState} from "react";
function BindFun() {
    const[bind,setBind]=useState("hello");
function Change(){
       setBind("i am changed");
   }
    return(
        <div>
            <h1> hello i am bind</h1>
            <h2>{bind}</h2>
            <button onClick={Change}>Change me </button>
        </div>
    )
}
export default BindFun;