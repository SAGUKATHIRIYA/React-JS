import React, {Component} from "react";
class BindClass extends Component{
    constructor(props){
        super(props);
        this.state={
            message:"hello"
        }
        // 2nd method bind =>// this.Changed=this.Changed.bind(this);
    }
    Changed=()=>{
      this.setState({
          message:"i am changed"
      })
    };
    render() {
        return(
            <div>
            <h1> i am bindClass </h1>
                <h2> {this.state.message} </h2>
                <button onClick={this.Changed}> click me </button>
                <button onClick={this.Changed.bind(this)}> cLICK </button>
            </div>
        )
    }
}
export default BindClass;