import React, {Component} from 'react';
import Image from './Image';

class Main extends Component{
        constructor(){
            console.log("Main constructor")
            super();
        this.state ={
            name: "Sagu kkkkkkkkkKathiriya",
            address : "katargam",
            handy: "757588656323",
            isShowing:false
        }
        };

        componentDidMount(){
            console.log("Main component has been mounted")
        }

        componentDidUpdate(){
               console.log("Main component has been Update");
        }

        componentDidUnmount(){
                    console.log("Main component Unmounted")
        }

render(){
    return(
        <div>
                <button onClick={ () => this.setState({ name: "Vishal nnnnnnnnNathani", address:"varaccha"})}> Click Me</button>
                <h1> my name is: {this.state.name} </h1>
                <h1> my address is: {this.state.address} </h1>
                <h1> my handy is: {this.state.handy} </h1>
                <hr/>
                <hr/>
                <button onClick={()=>this.setState({isShowing: !this.state.isShowing})} >   Hide/Show  </button>
                {
                    this.state.isShowing ? <Image></Image> : ""
                }

        </div>
    )
}
}
export default Main;