import React,{Component} from 'react';

class Image extends Component{
    constructor(){
        console.log("Img component constructor")
        super()
    }
    componentDidMount(){
        console.log("img component mounted")
    }

    componentWillUnmount(){
        console.log("img component has been unmounted")
    }
    render(){
        return(
            <div>
                <h1> i am Image Component </h1>



            </div>
        )
    }
}
export default Image;

//                <div class="image">
                 //                        <img src={this.state.Image} id="img-change" alt={this.state.imageAlt}/>
                 //               </div>
                 //