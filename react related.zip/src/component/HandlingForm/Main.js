import React, {useState} from "react";
function Main() {
    const[name,setName]=useState("");
    const[tnc,setTnc]=useState(false);
    const[interest,setInterest]=useState("");
    function getData(e) {
        console.log(name,tnc,interest);
        e.preventDefault();
    }
    return(
        <div className="container" onClick={(e)=>{
            // console.log('-------------on Div-------------->',e)
        }}>
            <h1> Handle form in React JS </h1>
            <form onSubmit={getData}>
                <input type="text" placeholder="enter the name" onChange={(e)=>{
                    // console.log('------------------------>',e)
                    setName(e.target.value)
                }}/> <br/> <br/>
                <select onChange={(e)=>setInterest(e.target.value)}>
                    <option>Select Options</option>
                    <option>Gujarati</option>
                    <option>Hindi</option>
                    <option>German</option>
                    <option>English</option>
                </select> <br/><br/>
                <input type="checkbox" onChange={(e)=>setTnc(e.target.checked)}/><span> Accept terms and conditions </span>
                <br/><br/>
                <button type="submit"> Submit</button>
                <button type="clear"> Clear</button>
            </form>
        </div>
    )
}
export default Main;