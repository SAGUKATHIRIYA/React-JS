import React from "react";
function PreventDefault() {
    function Handle(e){
        e.preventDefault();
        console.log("hello i am ");
    }

    return(
        <div>
            <h1> i am PreventDefault</h1>
            <form onSubmit={Handle}>
            <button> click me </button>
            </form>
        </div>
    );
}
export default  PreventDefault;

// PreventDefault=> default value ne submit thata roke
// form big hoy tema khbar pade