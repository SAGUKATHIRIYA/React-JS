import React, {Component} from "react";
class Simple extends Component{
    constructor(props) {
        super(props);
        this.state = {
            name: "sagu",
            age: 41,
            address:"kataragam",
            number:741852963
        };
    }
    changeName=()=>{
        this.setState({name:"mahi", address:"varaccha", age:58, number:7442663220558});
    };
    render() {
        return(
            <div>
                <h1> i am setstate</h1>
                <h1> My name is:{this.state.name}</h1>
                <h2> My age is :{this.state.age}</h2>
                <h2> My address is: {this.state.address}</h2>
                <h2> My number is: {this.state.number}</h2>
                <button onClick={this.changeName}> click me</button>
            </div>
        )
    }
}
export default Simple;