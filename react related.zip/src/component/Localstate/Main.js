import React, {Component} from 'react';
class Main extends Component{
        constructor(){
            super();
        this.state ={
            name: "Sagu Kathiriya",
            address : "katargam",
            handy: "757588656323"
        }
        };

render(){
    return(
        <div>
                <button onClick={ () => this.setState({ name: "Vishal Nathani"})}> Click Me</button>
                <h1> my name is: {this.state.name} </h1>
                <h1> my address is: {this.state.address} </h1>
                <h1> my handy is: {this.state.handy} </h1>
        </div>
    )
}
}
export default Main;