import React, {Component} from 'react';

class Change extends Component{
     constructor(){
     super();
     this.state = {
        name: "sagu kathiriya",
        address: "katargam",
        number: "541521321"
     }
     }
      ChangeName=()=>{
                       this.setState({name:"Vishal Nathani"})
                       this.setState({address:"umra"})
                       this.setState({number:"56563565664"})
                 }
      consoleClick=()=>{
                    console.log("this is a clicked")
                    document.write("hello");
       }

     render(){

        return(
            <div>
                <h2> it is name is:  {this.state.name} </h2>
                <h2> it is address is: {this.state.address} </h2>
                <h2> es is my number: {this.setState.number} </h2>
                <button onClick={ () => this.setState({ name: "BVM iNFOTECH ", address: "jakatnaka" , number:"858522552"})}> Click Me</button>
                <button onClick={()=>{this.ChangeName()}}> Click Me </button>
                <button onClick={this.consoleClick}> ConsoleClick </button>
          </div>
        )
     }
}
export default Change;