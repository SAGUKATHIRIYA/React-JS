import React, {useState} from "react";

function Count() {
    const[count,setCount]=useState(0);

    function countOne() {
            setCount(count+1);
    }
        return(
            <div>
                <h1> I am count function </h1>
                {/*<p>You clicked me  {count} I am counted </p>*/}
                <button style={{textAlign:"center", color:"blue"}}> {count} </button>
                <button onClick={countOne}> Click me </button>
            </div>
        )
}
export default Count;