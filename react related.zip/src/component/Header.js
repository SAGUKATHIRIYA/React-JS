import React, {Component} from 'react';
import './Style.css'
export default class Header extends Component{
    render(){
        return <h1 className='color'> i am Header class </h1>,
        <h2 style={{backgroundColor:"red", color:"blue"}}> it's a internal CSS </h2>
    }
};
// External CSS -> DO FILE ANS THEN UPLOAD IT'S EXTERNAL CSS
//INTERNAL CSS -> STYLE USE IN A DIRECTLY IN TAG WITH USE OF JS {} -> ANDAR OBJECT BANAV AMATE PACHU {}